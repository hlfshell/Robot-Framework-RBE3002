'''

'''

from RobotClass import *


class Behavior:

	__init__(self):
		pass

	update(self, robotData, robotMap):
		pass
